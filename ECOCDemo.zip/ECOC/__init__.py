# -*- coding: utf-8 -*-
# author: sunmengxin
# time: 2018/1/30 17:06
# file: __init__.py.py
# description:

import ECOCDemo.ECOC.Classifier
import ECOCDemo.ECOC.Criterion
import ECOCDemo.ECOC.Distance
import ECOCDemo.ECOC.Greedy_Search
import ECOCDemo.ECOC.Matrix_tool
import ECOCDemo.ECOC.SFFS
