"""
this model define some method to read data from files
"""

import numpy as np
import pandas as pd
import re
from sklearn.preprocessing import StandardScaler



# data, label = read_Microarray_Dataset(r'E:\XMU\Data\Micro array\microarray\Breast_train.csv')
